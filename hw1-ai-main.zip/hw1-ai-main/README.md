## Assignment 1

Here is a record of the work for assignment 1.
